#!/bin/sh
#
# This is run by the kernel after the last task is removed from a
# control group in the openrc hierarchy.

cgroup=/sys/fs/cgroup/openrc
PATH=/bin:/usr/bin:/sbin:/usr/sbin
if [ -d ${cgroup}/$1 ]; then
	rmdir ${cgroup}/$1
fi
